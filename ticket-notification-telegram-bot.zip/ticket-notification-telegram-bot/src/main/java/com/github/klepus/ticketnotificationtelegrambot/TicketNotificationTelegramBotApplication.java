package com.github.klepus.ticketnotificationtelegrambot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketNotificationTelegramBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketNotificationTelegramBotApplication.class, args);
	}

}
